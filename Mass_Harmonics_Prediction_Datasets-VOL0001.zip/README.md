# Mass Harmonics Prospective Prediction Dataset
## Volume I

**Volume ID:** `MH-PRED-V1`  
**Dataset version:** `1.0`  
**Author:** Thomas Russell Giboney  
**Affiliation:** UMtts Institute  
**Prepared:** 2026-07-10

This Volume is a structured prospective prediction dataset containing seven release-target papers and 49 machine-readable prediction records.

## Front Door

Open first:

`Data/MH_PRED_V1_Prediction_Index.csv`

The aggregate CSV contains every target prediction, source-fixed numerical value or invariant, eligible terrain, directional readout, failure condition, source-paper location, and stable prediction handle.

## Citation Handles

Cite the Volume DOI together with the row handle:

`<Volume DOI>, MH-PRED-V1-EUCLID-P1`

Examples:

- `MH-PRED-V1-WWPDB-P2`
- `MH-PRED-V1-RUBIN-R2`
- `MH-PRED-V1-ICHEP-P4`
- `MH-PRED-V1-MICRONS-M6`
- `MH-PRED-V1-LVK-P1`
- `MH-PRED-V1-GAIA-P8`

The handle identifies the prediction. The corresponding Markdown paper supplies the full derivation.

## File Architecture

- `Data/MH_PRED_V1_Prediction_Index.csv` — all predictions in one lightweight index.
- `Data/MH_PRED_V1_01_Euclid.csv` through `Data/MH_PRED_V1_07_Gaia_DR4.csv` — one machine-readable file per release target.
- `Papers/` — the seven complete source papers containing the derivations.
- `MANIFEST.json` — neutral file sizes and SHA-256 hashes.

## Interpretation Rule

The CSV records are the prospective claims. The Markdown papers explain how each claim was derived.

Future outcome measurements, comparison tables, and scoring records must be published separately. Volume I prediction rows are not overwritten after terrain opens.

## Core Schema

- `Prediction_Handle` — stable row-level identifier.
- `Target_Prediction` — the complete target-facing prediction.
- `Numerical_Target_or_Invariant` — exact value, range, ratio, equation, or structural invariant.
- `Eligibility` — terrain conditions required before the prediction can be evaluated.
- `Failure_Condition` — the declared contradiction surface.
- `Source_Paper` and `Source_Section` — derivational custody.
- `Row_SHA256` — SHA-256 of the canonical row content excluding the hash field itself.

**TRUTH > COMFORT. Always.**
